﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.EmpSalary = New System.Windows.Forms.TextBox()
        Me.CalcRaise = New System.Windows.Forms.Button()
        Me.ClearBtn = New System.Windows.Forms.Button()
        Me.exitBtn = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(308, 47)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(181, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Enter Employee's Salary"
        '
        'EmpSalary
        '
        Me.EmpSalary.Location = New System.Drawing.Point(325, 103)
        Me.EmpSalary.Name = "EmpSalary"
        Me.EmpSalary.Size = New System.Drawing.Size(144, 26)
        Me.EmpSalary.TabIndex = 1
        '
        'CalcRaise
        '
        Me.CalcRaise.Location = New System.Drawing.Point(325, 153)
        Me.CalcRaise.Name = "CalcRaise"
        Me.CalcRaise.Size = New System.Drawing.Size(144, 54)
        Me.CalcRaise.TabIndex = 2
        Me.CalcRaise.Text = "Calculate Raise"
        Me.CalcRaise.UseVisualStyleBackColor = True
        '
        'ClearBtn
        '
        Me.ClearBtn.Location = New System.Drawing.Point(312, 234)
        Me.ClearBtn.Name = "ClearBtn"
        Me.ClearBtn.Size = New System.Drawing.Size(77, 31)
        Me.ClearBtn.TabIndex = 3
        Me.ClearBtn.Text = "Clear"
        Me.ClearBtn.UseVisualStyleBackColor = True
        '
        'exitBtn
        '
        Me.exitBtn.Location = New System.Drawing.Point(395, 234)
        Me.exitBtn.Name = "exitBtn"
        Me.exitBtn.Size = New System.Drawing.Size(94, 31)
        Me.exitBtn.TabIndex = 4
        Me.exitBtn.Text = "E&xit"
        Me.exitBtn.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(809, 336)
        Me.Controls.Add(Me.exitBtn)
        Me.Controls.Add(Me.ClearBtn)
        Me.Controls.Add(Me.CalcRaise)
        Me.Controls.Add(Me.EmpSalary)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Employee Raise Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents EmpSalary As TextBox
    Friend WithEvents CalcRaise As Button
    Friend WithEvents ClearBtn As Button
    Friend WithEvents exitBtn As Button
End Class
