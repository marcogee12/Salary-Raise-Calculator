﻿Public Class Form1
    Private Sub CalcRaise_Click(sender As Object, e As EventArgs) Handles CalcRaise.Click
        Dim FivePercent As Double = EmpSalary.Text * 1.05
        Dim EightPercent As Double = EmpSalary.Text * 1.08
        Dim Raise1 As String = "Employee's 5% raise salary would be " & FormatCurrency(FivePercent.ToString) & ". "
        Dim Raise2 As String = "Employee's 8% raise salary would be " & FormatCurrency(EightPercent.ToString) & ". "
        MessageBox.Show(Raise1 & Raise2)
    End Sub

    Private Sub exitBtn_Click(sender As Object, e As EventArgs) Handles exitBtn.Click
        Me.Close()
    End Sub

    Private Sub ClearBtn_Click(sender As Object, e As EventArgs) Handles ClearBtn.Click
        EmpSalary.Clear()
    End Sub

    Private Sub EmpSalary_TextChanged(sender As Object, e As EventArgs) Handles EmpSalary.TextChanged

    End Sub
End Class
